package com.trading.service;
 
import java.util.List;
import java.util.Map;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.trading.mapper.TradingMapper;
 
@Service
public class TradingServiceImpl implements TradingService{
 
    @Autowired
    TradingMapper mapper;
    
    @Override
    public List<Map<String, Object>> SelectAllList() throws Exception {
        return mapper.SelectAllList();
    }
 
}