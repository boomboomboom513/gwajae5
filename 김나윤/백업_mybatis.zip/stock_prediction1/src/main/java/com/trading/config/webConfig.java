//package com.trading.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
////import com.trading.filter.LoginFilter;
//
//@Configuration
//public class webConfig {
//
//	@Autowired
//	private LoginFilter loginFilter;
//	
//	@Bean
//	public FilterRegistrationBean<LoginFilter> loginFilterRegistrationBean() {
//		FilterRegistrationBean<LoginFilter> registration = 
//				new FilterRegistrationBean<LoginFilter>(loginFilter);
//		registration.addUrlPatterns("/**");
//		registration.setOrder(1);
//		return registration;
//	}
//	
//}