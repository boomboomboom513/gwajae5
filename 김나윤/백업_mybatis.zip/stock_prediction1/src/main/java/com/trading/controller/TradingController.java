//package com.trading.controller;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import org.junit.Test;
//public class TradingController {
//
//	@Test
//	public void test() throws Exception {
//	    Class.forName("org.mariadb.jdbc.Driver"); // 마리아DB
//	    // Class.forName("com.mysql.jdbc.Driver"); MySQL
//
//	    Connection con = DriverManager.getConnection("jdbc:mariadb://34.64.46.27:3306/big16", "root", "Kny3229!");// 마리아DB
//	    // Connection con =     DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test","root","passwd"); MySQL
//	    System.out.println(con);
//	    }
//
//}
//
package com.trading.controller;
import java.util.List;
import java.util.Map;
 
import javax.annotation.Resource;
 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
 
import com.trading.service.TradingService;
 
@RestController
public class TradingController {
    
    @Resource
    private TradingService service;
    
    @RequestMapping(value="list")
    public ModelAndView AllListView(Map<String, Object> map) throws Exception{
        ModelAndView mv = new ModelAndView();
        
        List<Map<String, Object>> AllList = service.SelectAllList();
        System.out.println(AllList);
        mv.addObject("Alllist", AllList);
        mv.setViewName("list");
        return mv;
    }
 
}
 