package com.trading.service;

import java.util.List;
import java.util.Map;
 
public interface TradingService {
  
    public List<Map<String, Object>> SelectAllList() throws Exception;
}